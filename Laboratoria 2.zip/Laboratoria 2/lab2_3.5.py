import sys
from glfw.GLFW import *
from OpenGL.GL import *

def startup():
    glClearColor(0.5, 0.5, 0.5, 1.0)

def update_viewport(window, width, height):
    if height == 0: height = 1
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glViewport(0, 0, width, height)
    aspectRatio = width / height
    if width <= height:
        glOrtho(-100.0, 100.0, -100.0 / aspectRatio, 100.0 / aspectRatio, 1.0, -1.0)
    else:
        glOrtho(-100.0 * aspectRatio, 100.0 * aspectRatio, -100.0, 100.0, 1.0, -1.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def draw_rect(x, y, a, b):
    glColor3f(1.0, 1.0, 1.0)
    glBegin(GL_TRIANGLES)
    glVertex2f(x, y)
    glVertex2f(x, y + b)
    glVertex2f(x + a, y + b)
    glVertex2f(x + a, y + b)
    glVertex2f(x + a, y)
    glVertex2f(x, y)
    glEnd()

def render(time):
    glClear(GL_COLOR_BUFFER_BIT)
    glLoadIdentity()
    draw_rect(-50.0, -50.0, 100.0, 100.0)
    draw_rect(10.0, 60.0, 30.0, 20.0)
    glFlush()

def main():
    if not glfwInit():
        sys.exit(-1)
    window = glfwCreateWindow(400, 400, "Laboratorium 2 - Zadanie 3.5", None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)
    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    update_viewport(None, 400, 400)
    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    glfwTerminate()

if __name__ == '__main__':
    main()
import sys
import random
from glfw.GLFW import *
from OpenGL.GL import *

def startup():
    glClearColor(0.5, 0.5, 0.5, 1.0)

def update_viewport(window, width, height):
    if height == 0: height = 1
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glViewport(0, 0, width, height)
    aspectRatio = width / height
    if width <= height:
        glOrtho(-100.0, 100.0, -100.0 / aspectRatio, 100.0 / aspectRatio, 1.0, -1.0)
    else:
        glOrtho(-100.0 * aspectRatio, 100.0 * aspectRatio, -100.0, 100.0, 1.0, -1.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def draw_rect_deformed(x, y, a, b, d):
    deformed_a = a * (1.0 + d)
    deformed_b = b * (1.0 + d)
    glColor3f(random.random(), random.random(), random.random())
    glBegin(GL_TRIANGLES)
    glVertex2f(x, y)
    glVertex2f(x, y + deformed_b)
    glVertex2f(x + deformed_a, y + deformed_b)
    glVertex2f(x + deformed_a, y + deformed_b)
    glVertex2f(x + deformed_a, y)
    glVertex2f(x, y)
    glEnd()

def render(time):
    glClear(GL_COLOR_BUFFER_BIT)
    glLoadIdentity()
    draw_rect_deformed(-90.0, 10.0, 50.0, 50.0, 0.3)
    draw_rect_deformed(-50.0, -80.0, 40.0, 40.0, random.uniform(0.0, 0.5))
    draw_rect_deformed(30.0, -40.0, 30.0, 60.0, random.uniform(0.0, 0.8))
    glFlush()

def main():
    if not glfwInit():
        sys.exit(-1)
    window = glfwCreateWindow(400, 400, "Laboratorium 2 - Zadanie 4.0", None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)
    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    update_viewport(None, 400, 400)
    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    glfwTerminate()

if __name__ == '__main__':
    main()
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from PIL import Image
import sys

id_tekstury_1 = 0
id_tekstury_2 = 0
aktualna_tekstura = 0


def wczytaj_teksture(nazwa_pliku):
    try:
        image = Image.open(nazwa_pliku)
    except IOError:
        print(f"Blad odczytu pliku: {nazwa_pliku}")
        return -1

    image = image.transpose(Image.FLIP_TOP_BOTTOM)
    img_data = image.convert("RGBA").tobytes()
    width, height = image.size

    tex_id = glGenTextures(1)

    glBindTexture(GL_TEXTURE_2D, tex_id)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)

    return tex_id


def startup():
    global id_tekstury_1, id_tekstury_2, aktualna_tekstura

    id_tekstury_1 = wczytaj_teksture("tekstura.png")
    id_tekstury_2 = wczytaj_teksture("tekstura2.png")

    aktualna_tekstura = id_tekstury_1


def display():
    global aktualna_tekstura
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    gluLookAt(0, 0, 5, 0, 0, 0, 0, 1, 0)

    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, aktualna_tekstura)

    glColor3f(1.0, 1.0, 1.0)

    glBegin(GL_QUADS)
    glTexCoord2f(0.0, 0.0);
    glVertex3f(-1.0, -1.0, 0.0)
    glTexCoord2f(1.0, 0.0);
    glVertex3f(1.0, -1.0, 0.0)
    glTexCoord2f(1.0, 1.0);
    glVertex3f(1.0, 1.0, 0.0)
    glTexCoord2f(0.0, 1.0);
    glVertex3f(-1.0, 1.0, 0.0)
    glEnd()

    glutSwapBuffers()


def klawisze(key, x, y):
    global aktualna_tekstura, id_tekstury_1, id_tekstury_2

    if key == b'1':
        aktualna_tekstura = id_tekstury_1

    if key == b'2':
        aktualna_tekstura = id_tekstury_2

    glutPostRedisplay()


def reshape(w, h):
    if h == 0: h = 1
    glViewport(0, 0, w, h)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, w / h, 0.1, 100)
    glMatrixMode(GL_MODELVIEW)


def main():
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(800, 600)
    glutCreateWindow(b"Lab 6 - Zadanie 3.5")

    startup()

    glutDisplayFunc(display)
    glutReshapeFunc(reshape)
    glutKeyboardFunc(klawisze)

    glutMainLoop()


if __name__ == "__main__":
    main()